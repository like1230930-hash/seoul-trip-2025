import React, { useState, useEffect } from 'react';
import { Expense } from '../types';

const AccountingView: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemAmount, setNewItemAmount] = useState('');
  const [currency, setCurrency] = useState<'KRW' | 'TWD'>('KRW');

  useEffect(() => {
    const saved = localStorage.getItem('ski_exp_final_v6');
    if (saved) {
      try {
        setExpenses(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse expenses", e);
      }
    }
  }, []);

  const saveExpenses = (newExpenses: Expense[]) => {
    setExpenses(newExpenses);
    localStorage.setItem('ski_exp_final_v6', JSON.stringify(newExpenses));
  };

  const addExpense = (who: 'me' | 'cup') => {
    if (!newItemName || !newItemAmount) return;
    const expense: Expense = {
      id: Date.now(),
      i: newItemName,
      a: newItemAmount,
      w: who,
      c: currency
    };
    const updated = [...expenses, expense];
    saveExpenses(updated);
    setNewItemName('');
    setNewItemAmount('');
  };

  const removeExpense = (index: number) => {
    if (window.confirm('確定刪除?')) {
      const updated = [...expenses];
      updated.splice(index, 1);
      saveExpenses(updated);
    }
  };

  // Calculations
  let total = 0;
  let paidByMe = 0;
  let paidByCup = 0;

  expenses.forEach(e => {
    const amount = parseInt(e.a, 10);
    total += amount;
    if (e.w === 'me') paidByMe += amount;
    else paidByCup += amount;
  });

  const diff = paidByMe - (total / 2);

  return (
    <div className="pb-24 animate-[fadeIn_0.3s_ease-out]">
      <div className="bg-slate-800 text-white p-6 rounded-[24px] shadow-xl mb-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-10 -mt-10 blur-xl"></div>
        <div className="text-xs text-slate-400 uppercase font-bold mb-1 relative z-10">Total Spent (Est.)</div>
        <div className="text-4xl font-black mb-6 font-mono relative z-10">₩{total.toLocaleString()}</div>
        <div className="flex gap-4 pt-4 border-t border-white/10 text-sm relative z-10">
            <div className="flex-1">
                <div className="text-xs text-slate-400 mb-0.5">我付</div>
                <div className="font-bold">₩{paidByMe.toLocaleString()}</div>
            </div>
            <div className="flex-1 text-right">
                <div className="text-xs text-slate-400 mb-0.5">杯付</div>
                <div className="font-bold">₩{paidByCup.toLocaleString()}</div>
            </div>
        </div>
      </div>

      <div className={`text-center mb-6 font-bold py-3 px-4 rounded-xl border ${diff > 0 ? 'bg-green-50 text-green-700 border-green-200' : diff < 0 ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-slate-50 text-slate-500'}`}>
        {diff > 0 
          ? `杯茛 需給你 ₩${Math.abs(diff).toLocaleString()}` 
          : diff < 0 
            ? `你需給 杯茛 ₩${Math.abs(diff).toLocaleString()}` 
            : '目前結清'}
      </div>

      <div className="bg-white p-5 rounded-[20px] shadow-sm border border-slate-200 mb-6">
        <div className="text-xs font-bold text-slate-400 mb-4 uppercase tracking-wider flex items-center">
            <i className="fas fa-plus-circle mr-2"></i> 新增消費
        </div>
        <div className="mb-3">
            <input 
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                placeholder="項目名稱 (例如: 晚餐)" 
                className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 focus:bg-white transition-all text-sm font-medium"
            />
        </div>
        <div className="flex gap-3 mb-4">
            <div className="relative w-1/3">
                <select 
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as any)}
                    className="w-full p-3 rounded-xl border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 appearance-none font-bold text-slate-700 text-sm"
                >
                    <option value="KRW">₩ KRW</option>
                    <option value="TWD">NT$ TWD</option>
                </select>
                <div className="absolute right-3 top-3.5 text-slate-400 pointer-events-none text-xs">
                    <i className="fas fa-chevron-down"></i>
                </div>
            </div>
            <input 
                type="number" 
                value={newItemAmount}
                onChange={(e) => setNewItemAmount(e.target.value)}
                placeholder="金額" 
                className="w-2/3 p-3 rounded-xl border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 focus:bg-white transition-all text-sm font-mono font-medium"
            />
        </div>
        <div className="flex gap-3">
            <button 
                onClick={() => addExpense('me')}
                className="flex-1 bg-blue-50 hover:bg-blue-100 py-3 rounded-xl font-bold text-blue-600 transition-colors active:scale-95 text-sm"
            >
                我先付
            </button>
            <button 
                onClick={() => addExpense('cup')}
                className="flex-1 bg-emerald-50 hover:bg-emerald-100 py-3 rounded-xl font-bold text-emerald-600 transition-colors active:scale-95 text-sm"
            >
                杯茛先付
            </button>
        </div>
      </div>

      <div className="space-y-3">
        {[...expenses].reverse().map((e, i) => {
            const originalIndex = expenses.length - 1 - i;
            return (
                <div key={e.id} className="flex justify-between items-center p-4 bg-white rounded-xl border border-slate-100 shadow-sm animate-[fadeIn_0.2s_ease-out]">
                    <div>
                        <div className="font-bold text-slate-700">{e.i}</div>
                        <div className="text-xs text-slate-400 mt-1 font-medium bg-slate-100 inline-block px-1.5 py-0.5 rounded">
                            {e.w === 'me' ? '我' : '杯'}先付
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="font-bold font-mono text-slate-800">
                            {e.c === 'TWD' ? 'NT$' : '₩'}{parseInt(e.a).toLocaleString()}
                        </div>
                        <button 
                            onClick={() => removeExpense(originalIndex)}
                            className="text-xs text-red-300 hover:text-red-500 mt-1 px-2 py-1 transition-colors"
                        >
                            <i className="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            );
        })}
        {expenses.length === 0 && (
            <div className="text-center text-slate-400 py-10 text-sm">
                尚無消費紀錄
            </div>
        )}
      </div>
    </div>
  );
};

export default AccountingView;