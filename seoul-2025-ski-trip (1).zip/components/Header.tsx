import React, { useRef, useEffect } from 'react';
import { TRIP_DATA } from '../constants';

interface HeaderProps {
  activeDate: string;
  setActiveDate: (date: string) => void;
}

const Header: React.FC<HeaderProps> = ({ activeDate, setActiveDate }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const activeBtnRef = useRef<HTMLDivElement>(null);
  const data = TRIP_DATA[activeDate];

  useEffect(() => {
    // Scroll active button into view nicely
    if (activeBtnRef.current && scrollRef.current) {
        const container = scrollRef.current;
        const btn = activeBtnRef.current;
        const scrollLeft = btn.offsetLeft - container.offsetWidth / 2 + btn.offsetWidth / 2;
        container.scrollTo({ left: Math.max(0, scrollLeft), behavior: 'smooth' });
    }
  }, [activeDate]);

  return (
    <div className="sticky top-0 z-50 transition-all duration-300 bg-white/95 backdrop-blur-md pt-safe border-b border-slate-100 shadow-sm">
      <div className="px-5 pt-4 mb-3 flex justify-between items-end">
        <div>
          <div className="text-xs font-bold text-blue-600 tracking-widest uppercase mb-1">
            {data.subtitle || ''}
          </div>
          <h1 className="text-2xl font-black text-slate-900 leading-tight">
            {data.title.split("/")[1]?.trim() || data.title}
          </h1>
        </div>
        <div className="bg-slate-50 px-3 py-2 rounded-xl border border-slate-100 text-center shadow-sm min-w-[60px]">
          <div className="text-lg text-slate-700">
            <i className={`fas ${data.weather.i}`}></i>
          </div>
          <div className="text-xs font-bold text-slate-500">{data.weather.t}</div>
        </div>
      </div>

      <div className="px-5 mb-1">
        <div className="flex items-center text-xs font-medium text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 shadow-sm">
          <i className="fas fa-tshirt mr-2.5 text-blue-400 text-sm"></i>
          <span className="leading-tight">{data.weather.tip || '享受旅程！'}</span>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex overflow-x-auto hide-scrollbar px-5 py-4 space-x-3 snap-x snap-mandatory scroll-pl-5"
      >
        {Object.keys(TRIP_DATA).map((date) => {
          const tripDay = TRIP_DATA[date];
          const d = new Date(date);
          const isActive = date === activeDate;
          
          return (
            <div
              key={date}
              ref={isActive ? activeBtnRef : null}
              onClick={() => setActiveDate(date)}
              className={`snap-center flex-shrink-0 flex flex-col items-center justify-center w-[64px] h-[84px] rounded-2xl cursor-pointer transition-all border duration-300 ${
                isActive
                  ? 'bg-slate-800 text-white border-slate-800 shadow-lg scale-105 ring-2 ring-slate-200 ring-offset-2'
                  : 'bg-white text-slate-400 border-slate-100 active:scale-95'
              }`}
            >
              <span className={`text-[10px] uppercase font-bold tracking-wider mb-1 ${isActive ? 'opacity-80' : 'opacity-60'}`}>
                {d.toLocaleDateString("en-US", { weekday: "short" })}
              </span>
              <span className="text-2xl font-black font-mono leading-none mb-1">
                {d.getDate()}
              </span>
              <i className={`fas ${tripDay.weather.i} text-[10px] ${isActive ? 'opacity-80 text-blue-200' : 'opacity-40'}`}></i>
            </div>
          );
        })}
        {/* Spacer to fix clipping at the end */}
        <div className="w-2 flex-shrink-0"></div>
      </div>
    </div>
  );
};

export default Header;