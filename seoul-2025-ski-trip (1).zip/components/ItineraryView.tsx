import React from 'react';
import { TRIP_DATA } from '../constants';
import { TripItem, Discovery } from '../types';
import {
  BoardingPass,
  SnackCard,
  TransitCard,
  ListCard,
  StandardCard,
} from './TripCards';

interface ItineraryViewProps {
  activeDate: string;
}

const DiscoveryCard: React.FC<{ data: Discovery }> = ({ data }) => (
  <div className="bg-gradient-to-br from-slate-700 to-slate-800 text-white rounded-[24px] p-6 mb-6 shadow-xl relative overflow-hidden">
    {/* Decorative background circle */}
    <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/5 rounded-full blur-3xl pointer-events-none"></div>
    
    <div className="relative z-10">
      <div className="text-xs font-bold text-blue-200 uppercase tracking-widest mb-3 flex items-center">
        <i className="fas fa-compass mr-2 animate-pulse"></i> 探索周邊
      </div>
      <h3 className="text-2xl font-black mb-3 leading-tight">{data.title}</h3>
      <p className="text-sm text-slate-200 mb-6 leading-relaxed font-medium opacity-90">{data.desc}</p>
      
      <div className="flex flex-col gap-3">
        {data.spots.map((s, i) => (
          <div key={i} className="bg-white/10 rounded-xl p-4 backdrop-blur-sm border border-white/10 active:bg-white/20 transition-colors">
            <div className="flex items-start">
               <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-200 flex items-center justify-center mr-3 flex-shrink-0 mt-0.5">
                  <i className="fas fa-map-marker-alt text-xs"></i>
               </div>
               <div>
                  <div className="font-bold text-base text-white leading-snug mb-1">{s.name}</div>
                  {s.desc && <div className="text-sm text-slate-300 leading-relaxed font-light">{s.desc}</div>}
                  {s.type && <div className="inline-block mt-2 text-[10px] font-bold bg-white/10 px-2 py-0.5 rounded text-slate-200">{s.type}</div>}
               </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const ItineraryView: React.FC<ItineraryViewProps> = ({ activeDate }) => {
  const dayData = TRIP_DATA[activeDate];

  return (
    <div className="pb-20 animate-[fadeIn_0.3s_ease-out]">
      {dayData.discovery && <DiscoveryCard data={dayData.discovery} />}
      
      {dayData.items.map((item, index) => {
        switch (item.type) {
          case 'flight':
            return <BoardingPass key={index} item={item} />;
          case 'snack':
            return <SnackCard key={index} item={item} />;
          case 'transit':
            return <TransitCard key={index} item={item} />;
          case 'list':
            return <ListCard key={index} item={item} />;
          default:
            return <StandardCard key={index} item={item} />;
        }
      })}
    </div>
  );
};

export default ItineraryView;