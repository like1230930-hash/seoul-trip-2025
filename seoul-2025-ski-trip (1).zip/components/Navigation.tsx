import React from 'react';

type Tab = 'itinerary' | 'accounting' | 'translate' | 'tools';

interface NavigationProps {
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const navItems: { id: Tab; icon: string; label: string }[] = [
    { id: 'itinerary', icon: 'fa-map', label: '行程' },
    { id: 'accounting', icon: 'fa-wallet', label: '記帳' },
    { id: 'translate', icon: 'fa-language', label: '翻譯' },
    { id: 'tools', icon: 'fa-suitcase', label: '工具' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 flex justify-around items-start pt-3 pb-safe h-[85px] z-50 shadow-[0_-1px_3px_rgba(0,0,0,0.02)]">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setActiveTab(item.id)}
          className={`nav-item flex flex-col items-center w-1/4 transition-colors duration-200 ${
            activeTab === item.id ? 'text-blue-600' : 'text-slate-400 hover:text-slate-500'
          }`}
        >
          <i className={`fas ${item.icon} text-xl mb-1`}></i>
          <span className="text-[10px] font-bold">{item.label}</span>
        </button>
      ))}
    </div>
  );
};

export default Navigation;