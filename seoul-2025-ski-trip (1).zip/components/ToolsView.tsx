import React, { useState, useEffect } from 'react';
import { ChecklistGroup } from '../types';

const INITIAL_CHECKLIST: ChecklistGroup[] = [
    { title: "證件與錢財", items: ["護照 (檢查效期)", "機票 (電子/紙本)", "現金 (韓幣)", "信用卡 (海外回饋)", "旅遊保險單"] }, 
    { title: "滑雪裝備", items: ["保暖長襪 (厚)", "發熱衣褲 (兩套)", "防水手套", "毛帽 (遮耳)", "圍脖/脖圍"] }, 
    { title: "電子用品", items: ["轉接頭 (韓國圓孔)", "行動電源", "充電線", "SIM卡/漫遊"] }, 
    { title: "藥品與雜物", items: ["感冒藥", "止痛藥", "腸胃藥", "暖暖包", "個人保養品"] }, 
    { title: "個人物品", items: [] }
];

const ToolsView: React.FC = () => {
  // State for calculators
  const [rate, setRate] = useState(43); // 1 TWD = 43 KRW roughly
  const [krwInput, setKrwInput] = useState('');
  const [taxInput, setTaxInput] = useState('');
  
  // State for checklist
  const [checklist, setChecklist] = useState<ChecklistGroup[]>(INITIAL_CHECKLIST);
  const [checkedItems, setCheckedItems] = useState<string[]>([]);
  const [newItem, setNewItem] = useState('');

  // Load data
  useEffect(() => {
    const savedRate = localStorage.getItem('ski_rate');
    if (savedRate) setRate(parseFloat(savedRate));

    const savedList = localStorage.getItem('ski_checklist_data_v2');
    if (savedList) setChecklist(JSON.parse(savedList));

    const savedChecked = localStorage.getItem('ski_checklist_checked_v2');
    if (savedChecked) setCheckedItems(JSON.parse(savedChecked));
  }, []);

  // Save helpers
  const updateChecklist = (newList: ChecklistGroup[]) => {
    setChecklist(newList);
    localStorage.setItem('ski_checklist_data_v2', JSON.stringify(newList));
  };

  const updateChecked = (newChecked: string[]) => {
    setCheckedItems(newChecked);
    localStorage.setItem('ski_checklist_checked_v2', JSON.stringify(newChecked));
  };

  // Calculator Logic
  const handleRateChange = (val: string) => {
    const r = parseFloat(val);
    if (!isNaN(r)) {
      setRate(r);
      localStorage.setItem('ski_rate', val);
    }
  };

  const calcTwd = (krw: string) => {
    const k = parseFloat(krw);
    if (isNaN(k)) return 0;
    return Math.round(k / rate);
  };

  const calcTaxRefund = (val: string) => {
    const v = parseFloat(val);
    if (isNaN(v)) return 0;
    if(v >= 30000 && v < 50000) return 2000;
    else if(v >= 50000 && v < 75000) return 3000;
    else if(v >= 75000) return 5000; // Simplified logic
    else if(v >= 30000) return Math.floor(v * 0.06);
    return 0;
  };

  // Checklist Logic
  const toggleCheck = (item: string) => {
    if (checkedItems.includes(item)) {
        updateChecked(checkedItems.filter(i => i !== item));
    } else {
        updateChecked([...checkedItems, item]);
    }
  };

  const addItem = () => {
    if (!newItem.trim()) return;
    const newList = [...checklist];
    let personalGroup = newList.find(g => g.title === "個人物品");
    if (!personalGroup) {
        personalGroup = { title: "個人物品", items: [] };
        newList.push(personalGroup);
    }
    personalGroup.items.push(newItem.trim());
    updateChecklist(newList);
    setNewItem('');
  };

  const removeItem = (groupIndex: number, itemIndex: number) => {
    if (window.confirm('Remove item?')) {
        const newList = [...checklist];
        const itemToRemove = newList[groupIndex].items[itemIndex];
        newList[groupIndex].items.splice(itemIndex, 1);
        updateChecklist(newList);
        // Also remove from checked if present
        if (checkedItems.includes(itemToRemove)) {
            updateChecked(checkedItems.filter(i => i !== itemToRemove));
        }
    }
  };

  return (
    <div className="pt-4 pb-24 animate-[fadeIn_0.3s_ease-out]">
      <h2 className="text-2xl font-black text-slate-900 mb-6 px-2">Utility Hub</h2>
      
      {/* Calculator Section */}
      <div className="bg-slate-900 text-white p-5 rounded-[24px] shadow-lg mb-8">
        <div className="flex justify-between items-center mb-4">
            <div className="text-xs text-slate-400 font-bold uppercase"><i className="fas fa-calculator mr-1"></i> 匯率換算</div>
            <div className="flex items-center text-xs text-slate-400 bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700">
                <span className="mr-2">1 TWD =</span>
                <input 
                    type="number" 
                    value={rate} 
                    onChange={(e) => handleRateChange(e.target.value)}
                    className="w-12 bg-transparent text-center border-b border-slate-500 text-white focus:outline-none focus:border-blue-400 font-mono font-bold"
                />
                <span className="ml-2">KRW</span>
            </div>
        </div>
        
        <div className="flex items-center gap-4 mb-6">
            <input 
                type="number" 
                placeholder="₩ 韓幣" 
                value={krwInput}
                onChange={(e) => setKrwInput(e.target.value)}
                className="w-1/2 bg-slate-800 border border-slate-700 rounded-xl p-4 text-white outline-none focus:border-blue-500 font-mono text-lg"
            />
            <i className="fas fa-arrow-right text-slate-600"></i>
            <div className="w-1/2 text-2xl font-bold font-mono text-right text-emerald-400">
                NT$ {calcTwd(krwInput).toLocaleString()}
            </div>
        </div>
        
        <div className="pt-4 border-t border-slate-800">
             <div className="text-xs text-slate-400 font-bold uppercase mb-2"><i className="fas fa-coins mr-1"></i> 購物退稅試算 (Est.)</div>
             <div className="flex items-center gap-3">
                 <input 
                    type="number" 
                    placeholder="消費金額 (₩)" 
                    value={taxInput}
                    onChange={(e) => setTaxInput(e.target.value)}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-blue-500"
                 />
                 <div className="text-sm text-blue-300 font-bold whitespace-nowrap">
                    可退 ₩{calcTaxRefund(taxInput).toLocaleString()}
                 </div>
             </div>
             <div className="text-[10px] text-slate-500 mt-2">*滿3萬韓元可退，約退6-7%</div>
        </div>
      </div>

      {/* Checklist Input */}
      <div className="bg-white p-5 rounded-[20px] shadow-sm border border-slate-200 mb-8">
        <div className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">新增清單項目</div>
        <div className="flex gap-2">
            <input 
                value={newItem}
                onChange={(e) => setNewItem(e.target.value)}
                placeholder="輸入物品名稱..." 
                className="flex-1 p-3 rounded-xl border border-slate-200 bg-slate-50 outline-none focus:border-blue-500 transition-colors text-sm"
            />
            <button 
                onClick={addItem}
                className="bg-blue-50 hover:bg-blue-100 text-blue-600 font-bold py-3 px-6 rounded-xl transition-colors text-sm"
            >
                加入
            </button>
        </div>
      </div>

      {/* Checklist Items */}
      <div className="space-y-4">
        {checklist.map((group, groupIndex) => (
            <div key={groupIndex} className="bg-white p-5 rounded-[20px] shadow-sm border border-slate-100">
                <h3 className="font-bold text-slate-800 mb-4 flex items-center text-sm uppercase tracking-wide">
                    <i className="fas fa-check-circle text-blue-500 mr-2"></i> {group.title}
                </h3>
                <div className="space-y-1">
                    {group.items.map((item, itemIndex) => {
                        const isChecked = checkedItems.includes(item);
                        return (
                            <div 
                                key={itemIndex} 
                                onClick={() => toggleCheck(item)}
                                className={`flex justify-between items-center p-3 rounded-xl cursor-pointer transition-all ${isChecked ? 'bg-slate-50' : 'hover:bg-slate-50'}`}
                            >
                                <div className="flex items-center">
                                    <div className={`w-5 h-5 rounded-md border flex items-center justify-center mr-3 transition-colors ${isChecked ? 'bg-blue-500 border-blue-500' : 'border-slate-300 bg-white'}`}>
                                        {isChecked && <i className="fas fa-check text-white text-xs"></i>}
                                    </div>
                                    <span className={`text-sm font-medium transition-colors ${isChecked ? 'text-slate-400 line-through' : 'text-slate-700'}`}>
                                        {item}
                                    </span>
                                </div>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); removeItem(groupIndex, itemIndex); }}
                                    className="text-slate-300 hover:text-red-400 p-2 transition"
                                >
                                    <i className="fas fa-times"></i>
                                </button>
                            </div>
                        );
                    })}
                </div>
            </div>
        ))}
      </div>

      {/* Emergency Contacts */}
      <div className="grid grid-cols-2 gap-3 mt-8">
        <a href="tel:1330" className="bg-red-50 p-4 rounded-2xl text-center border border-red-100 active:scale-[0.98] transition-transform">
            <div className="text-2xl mb-2">📞</div>
            <div className="font-bold text-red-600 text-sm">翻譯熱線 1330</div>
        </a>
        <a href="tel:112" className="bg-red-50 p-4 rounded-2xl text-center border border-red-100 active:scale-[0.98] transition-transform">
            <div className="text-2xl mb-2">🚓</div>
            <div className="font-bold text-red-600 text-sm">警察 112</div>
        </a>
      </div>
    </div>
  );
};

export default ToolsView;