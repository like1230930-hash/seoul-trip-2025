import React from 'react';
import { PHRASES } from '../constants';

const TranslationView: React.FC = () => {
  const playSound = (text: string) => {
    // Simple alert for now, could integrate speech synthesis API
    if ('speechSynthesis' in window) {
       const utterance = new SpeechSynthesisUtterance(text);
       utterance.lang = 'ko-KR';
       window.speechSynthesis.speak(utterance);
    } else {
        alert(`Pronunciation: ${text}`);
    }
  };

  return (
    <div className="pt-2 pb-24 animate-[fadeIn_0.3s_ease-out]">
      <h2 className="text-2xl font-black text-slate-900 mb-6 px-2">基本用語 (Basic Korean)</h2>
      <div className="grid grid-cols-2 gap-3">
        {PHRASES.map((p, idx) => (
          <button
            key={idx}
            onClick={() => playSound(p.k)}
            className="bg-white rounded-[18px] p-5 text-center shadow-sm border border-slate-200 hover:border-blue-300 active:scale-[0.98] transition-all flex flex-col items-center justify-center min-h-[140px]"
          >
            <div className="font-bold text-xl text-slate-800 mb-1">{p.k}</div>
            <div className="text-xs font-bold text-red-500 uppercase tracking-wide mb-3">{p.p}</div>
            <div className="text-sm text-slate-500 font-medium">{p.m}</div>
            <i className="fas fa-volume-up text-slate-200 mt-3 text-xs"></i>
          </button>
        ))}
      </div>
      <div className="mt-6 text-center text-xs text-slate-400">
        點擊卡片可播放發音 (需瀏覽器支持)
      </div>
    </div>
  );
};

export default TranslationView;