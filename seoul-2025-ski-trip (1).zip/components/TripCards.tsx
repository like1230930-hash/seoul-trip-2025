import React from 'react';
import { TripItem, TransitStep, SnackItem } from '../types';

interface CardProps {
  item: TripItem;
}

const NaverButton: React.FC<{ url?: string; query?: string; address?: string }> = ({ url, query, address }) => {
  const finalUrl = url || (query || address ? `https://map.naver.com/v5/search/${encodeURIComponent(query || address || '')}` : null);
  
  if (!finalUrl) return null;

  return (
    <a
      href={finalUrl}
      target="_blank"
      rel="noreferrer"
      className="flex items-center justify-center bg-[#03C75A] text-white font-bold rounded-xl p-3 mt-4 text-sm w-full active:opacity-90 transition-opacity"
    >
      <span className="font-black text-lg mr-2 font-serif">N</span> 開啟 Naver Map 導航
    </a>
  );
};

const TagPill: React.FC<{ text: string }> = ({ text }) => {
  let colorClass = "bg-slate-100 text-slate-600 border-slate-200"; // default
  
  if (text.includes("必") || text.includes("租") || text.includes("金")) {
    colorClass = "bg-orange-50 text-orange-700 border-orange-100";
  } else if (text.includes("集") || text.includes("遲") || text.includes("注") || text.includes("教") || text.includes("車")) {
    colorClass = "bg-blue-50 text-blue-700 border-blue-100";
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold mr-1.5 mb-1.5 border ${colorClass} leading-none`}>
      {text}
    </span>
  );
};

export const BoardingPass: React.FC<CardProps> = ({ item }) => {
  return (
    <div className="bg-white rounded-[24px] shadow-md mb-6 border border-slate-200 overflow-hidden">
      <div className="px-6 py-3 bg-white border-b border-slate-100 flex justify-between items-center">
        <span className="text-[10px] font-bold tracking-widest opacity-50 uppercase">Boarding Pass</span>
        <div className="flex items-center gap-2 text-slate-800">
          <i className="fas fa-plane text-sm"></i>
          <span className="font-bold text-sm">{item.airline}</span>
        </div>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-end mb-4">
          <div>
            <div className="text-4xl font-black text-slate-900 font-mono">{item.from}</div>
            <div className="text-[10px] text-slate-500 font-bold mt-1 bg-slate-100 inline-block px-2 py-1 rounded">{item.fromCity}</div>
          </div>
          <div className="flex-1 flex flex-col items-center px-4 pb-2">
            <div className="text-xs font-mono font-bold text-blue-600 mb-1">{item.code}</div>
            <div className="w-full h-[2px] bg-slate-200 relative">
              <div className="absolute right-0 -top-[3px] w-2 h-2 bg-slate-300 rounded-full"></div>
              <i className="fas fa-plane absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-slate-300 text-xs transform rotate-90"></i>
            </div>
          </div>
          <div className="text-right">
            <div className="text-4xl font-black text-slate-900 font-mono">{item.to}</div>
            <div className="text-[10px] text-slate-500 font-bold mt-1 bg-slate-100 inline-block px-2 py-1 rounded">{item.toCity}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-8 pt-4 border-t border-dashed border-slate-200">
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Departure</div>
            <div className="text-xl font-bold text-slate-800 font-mono">{item.fromTime}</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Arrival</div>
            <div className="text-xl font-bold text-blue-600 font-mono">{item.toTime}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const SnackCard: React.FC<CardProps> = ({ item }) => {
  return (
    <div className="bg-slate-800 text-slate-200 rounded-[20px] p-5 mb-5 shadow-lg relative overflow-hidden">
        <div className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest mb-4 flex items-center">
            <i className="fas fa-moon mr-2"></i> {item.title || '深夜補給'}
        </div>
        <div className="space-y-4">
            {item.items?.map((s, idx) => {
                const name = typeof s === 'string' ? s : s.name;
                const desc = typeof s === 'string' ? '' : s.desc;
                return (
                    <div key={idx} className="flex items-start border-b border-white/10 pb-3 last:border-0 last:pb-0">
                         <i className="fas fa-utensils text-yellow-400 mt-1 mr-3 text-xs"></i>
                         <div>
                             <div className="font-bold text-white text-sm">{name}</div>
                             {desc && <div className="text-xs text-indigo-200 mt-0.5">{desc}</div>}
                         </div>
                    </div>
                )
            })}
        </div>
    </div>
  );
};

export const TransitCard: React.FC<CardProps> = ({ item }) => {
  return (
    <div className="bg-white border border-slate-200 rounded-[16px] p-5 mb-4 shadow-sm">
      <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-100">
        <div className="text-xs font-extrabold text-slate-400 uppercase tracking-wider flex items-center">
            <i className="fas fa-route mr-1.5"></i> 交通方式
        </div>
        <div className="text-sm font-bold text-slate-800 flex items-center">
          {item.from} <i className="fas fa-arrow-right mx-2 text-slate-300 text-xs"></i> {item.to}
        </div>
      </div>
      <div className="space-y-0 relative">
        {item.steps?.map((step: TransitStep, idx) => (
          <div key={idx} className="flex items-start relative pb-6 last:pb-0 group">
             {/* Line connector */}
             {idx !== (item.steps?.length || 0) - 1 && (
                <div className="absolute left-[9px] top-2 bottom-0 w-[2px] bg-slate-200 group-hover:bg-slate-300 transition-colors"></div>
             )}
             
             {/* Dot */}
             <div 
                className={`w-5 h-5 rounded-full z-10 flex-shrink-0 border-[3px] border-white shadow-[0_0_0_1px_#E2E8F0] mr-4 ${!step.color ? 'bg-slate-400' : ''} ${step.color || ''}`}
             ></div>
             
             <div className="flex-1 -mt-1">
                <div className="flex items-center mb-1.5 flex-wrap gap-2">
                    <span className={`text-[11px] font-black text-white px-2 py-0.5 rounded-[6px] ${step.color || 'bg-slate-400'} min-w-[45px] text-center shadow-sm`}>
                        {step.name}
                    </span>
                    <span className="text-sm font-bold text-slate-800 leading-tight">{step.desc}</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                    {step.dir && (
                        <span className="text-xs text-slate-500 font-medium bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">
                            {step.dir}
                        </span>
                    )}
                    {step.exit && (
                        <span className="inline-flex items-center bg-amber-100 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                            {step.exit}
                        </span>
                    )}
                    {step.time && (
                        <div className="text-xs text-slate-400 flex items-center font-medium">
                            <i className="fas fa-clock mr-1 text-[10px]"></i>{step.time}
                        </div>
                    )}
                </div>
             </div>
          </div>
        ))}
      </div>
      {item.tips && (
        <div className="mt-5 text-xs font-medium text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 flex items-start">
            <i className="fas fa-info-circle mr-2 mt-0.5 text-blue-500"></i>
            <span className="leading-relaxed">{item.tips}</span>
        </div>
      )}
    </div>
  );
};

export const ListCard: React.FC<CardProps> = ({ item }) => {
  return (
    <div className="bg-white rounded-[20px] p-6 mb-4 shadow-sm border border-slate-100">
      <div className="flex justify-between items-start mb-2">
        <div className="text-xs font-mono font-bold text-slate-400 bg-slate-100 px-2 py-1 rounded">{item.time}</div>
        <div className="text-sm font-medium text-slate-500">{item.sub || item.subtitle}</div>
      </div>
      <h3 className="text-lg font-bold text-slate-900 leading-tight mb-3">{item.title}</h3>
      {item.desc && <div className="text-sm text-slate-600 mb-4 leading-relaxed" dangerouslySetInnerHTML={{__html: item.desc}}></div>}
      
      <ul className="space-y-2 mb-4">
        {item.list?.map((li, idx) => (
            <li key={idx} className="flex items-start text-sm text-slate-600 relative pl-4">
                <span className="absolute left-0 top-2 w-1 h-1 rounded-full bg-slate-300"></span>
                <span dangerouslySetInnerHTML={{__html: li}}></span>
            </li>
        ))}
      </ul>

      <div className="flex flex-wrap gap-1 mb-2">
        {item.tags?.map((tag, idx) => <TagPill key={idx} text={tag} />)}
      </div>

      <NaverButton url={item.naverLink} />
    </div>
  );
};

export const StandardCard: React.FC<CardProps> = ({ item }) => {
  const iconMap: Record<string, string> = { 
    transport: "fa-train-subway", 
    hotel: "fa-bed", 
    food: "fa-utensils", 
    shopping: "fa-bag-shopping", 
    activity: "fa-person-skiing" 
  };
  const icon = iconMap[item.type] || "fa-circle";
  
  const colorMap: Record<string, string> = { 
    transport: "text-blue-500", 
    hotel: "text-purple-500", 
    food: "text-orange-500", 
    shopping: "text-pink-500", 
    activity: "text-cyan-500" 
  };
  const iconColor = colorMap[item.type] || "text-slate-500";

  return (
    <div className="bg-white rounded-[20px] p-6 mb-4 shadow-sm border border-slate-100 active:scale-[0.99] transition-transform duration-100">
      <div className="flex items-start gap-4">
        <div className={`w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-xl ${iconColor} border border-slate-100 flex-shrink-0`}>
          <i className={`fas ${icon}`}></i>
        </div>
        <div className="flex-1">
            <div className="text-xs font-mono font-bold text-slate-400 mb-1 tracking-wide">{item.time}</div>
            <h3 className="text-lg font-bold text-slate-900 leading-tight mb-1">{item.title}</h3>
            <div className="text-sm font-medium text-slate-500 flex flex-wrap items-center gap-2">
                {item.sub || item.subtitle}
                {item.exit && (
                    <span className="inline-flex items-center bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                        <i className="fas fa-door-open mr-1"></i>{item.exit}
                    </span>
                )}
            </div>
            
            <div className="flex flex-wrap gap-1 mt-3">
                {item.tags?.map((tag, idx) => <TagPill key={idx} text={tag} />)}
            </div>
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-slate-50">
          <div className="text-sm text-slate-600 leading-relaxed mb-3" dangerouslySetInnerHTML={{__html: item.desc || ''}}></div>
          {item.tips && (
              <div className="text-xs text-amber-700 bg-amber-50 p-3 rounded-xl border border-amber-100 flex items-start">
                  <i className="fas fa-lightbulb mr-2 mt-0.5 text-amber-500"></i>
                  <span>{item.tips}</span>
              </div>
          )}
          <NaverButton url={item.naverLink} query={item.mapQuery} address={item.address} />
      </div>
    </div>
  );
};